<section class="onerow">
	<div class="col12">
		<p class="welcome">Account Summary</p>
	</div>
</section>

<section class="onerow">
	<div class="col12">
		<div class="toggle">Auto Insurance <div class="right">&ndash;</div></div>
	</div>
</section>

<section class="onerow primary form-container">
	<div class="col12">

		<h3>2012 Honda Civic</h3>
		<p>Choose a payment option to see your annual costs or savings</p>

		<div class="form">
			<label class="radio" for="radio_1">
				<input type="radio" value="1" name="default_radio" id="radio_1">
				Pay twice a year
			</label>
			<label class="radio" for="radio_2">
				<input type="radio" value="2" name="default_radio" id="radio_2">
				Pay twice a year with a monthly contribution to a savings plan (?)
			</label>
			<label class="radio" for="radio_3">
				<input type="radio" value="3" name="default_radio" id="radio_3">
				Pay twice a year with a monthly contribution to a savings plan (?)
			</label>
		</div>
	</div>
</section>

<section class="onerow secondary">
	<div class="col8 third-row account">
		<h4>Per Payment Cycle</h4>
		<img src="css/img/pie.png" class="pie" />
		<p class="white">You save 20%!</p>
	</div>
	<div class="col4 last third-row account">
		<h4>Annual Total to Date</h4>
		<img src="css/img/bar.png" class="bar" />
		<p>50% of annual payments saved by June 2014</p>
	</div>
</section>

<section class="onerow">
	<div class="col12">
		<div class="toggle last">Home Insurance <div class="right">+</div></div>
	</div>
</section>

