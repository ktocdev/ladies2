<section class="onerow">
	<div class="col12">
		<p class="welcome">Welcome, Joel!</p>
	</div>
</section>

<section class="onerow primary">
	<div class="col6 savings styles">
		<img src="css/img/moneybags.png" class="moneybags" />
		<h3>Visualize Your Savings</h3>
		<p>See how understanding your data can help you prepare for the unexpected.</p>
		<a href="#" class="grey-block">Reduce your costs and save $40/mo <span class="arrow white"><img src="css/img/arrow-white.png"></span></a>
	</div>
	<div class="col6 last styles">
		<img src="css/img/tools.png" class="tools" />
		<h3>Action Items</h3>
		<a href="#" class="plain-block"> Honda Civic 50,000 mile tune-up <span class="arrow white"><img class=""src="css/img/arrow-white.png"></span></a>
		<a href="#" class="plain-block">Hail damage roof inspection <span class="arrow white"><img class=""src="css/img/arrow-white.png"></span></a>
	</div>
</section>

<section class="onerow secondary">
	<div class="col8 tip third-rows styles">
		<img src="css/img/deers.png" class="deer" />
		<h4>OH DEER!</h4>
		<p>It’s deer season and 53 of your neighbors hit one last year!</p>
		<p>If you hit a deer, take one of the following steps:</p>
		<hr>
		<img src="css/img/boom.png" class="boom" />
		<ul>
			<li>Move your vehicle to a safe location</li>
			<li>Call the police</li>
			<li>Contact your agent</li>
		</ul>
	</div>
	<div class="col4 last third-row styles">
	<img src="css/img/gears.png" class="gears" />
		<h4>Want to see more custom advice?</h4>
		
			<a href="#" class="red-block">Add more info <span class="arrow"><img class="arrow"src="css/img/arrow-blue.png"></span></a>
	</div>

</section>

<!-- <section class="onerow primary">
	<div class="col6 buttons">
		<label>
			<input class="radio-one" name="savings" type="radio">savings
		</label>
		<label>
			<input class="radio-second" name="savings" type="radio">savings
		</label>
		<label>
			<input class="radio-three" name="savings" type="radio">savings
		</label>
	</div>
	<div class="col6 bar-graph">
		<div class="bar-one opacity"></div>
		<div class="bar-two opacity"></div>
		<div class="bar-three opacity"></div>
	</div>
</section> -->

<section class="onerow secondary">
	<div class="col12">
		<h5>Lincoln Park Happenings</h5>
		<?php include_once('templates/map.php'); ?>
		<div class="coupon">
			<img src="css/img/purple.png" class="purple" />
			<h4>FREE CLASSES</h4>
			<p>At State Farm Next Door</p>
		</div>
	</div>
</section>
