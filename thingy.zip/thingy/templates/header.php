<header>
	<img src="css/img/sflogo.png" />
	<!--<nav class="main-nav">
		<ul>
			<li><a href="#">Bank</a></li>
			<li><a href="#">Money</a></li>
			<li><a href="#">iPad</a></li>
		</ul>
	</nav>-->
</header>