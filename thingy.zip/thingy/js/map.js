var map,
    zoomLvl = 16,
    locationImg = 'css/img/location.png',
    bluePointer = 'css/img/blue.png',
    myLocation = new google.maps.LatLng(41.934498,-87.649763),
		nextDoor = new google.maps.LatLng(41.933013,-87.645793),
    nextDoorDesc = '<img src="css/img/nextdoor.jpg" class="mapImg" /><strong>Next Door</strong><br><em>Coaching, Classes, Community.</em><br><small>659 W Diversey Parkway<br>Chicago, IL 60614<br><a href="javascript:void(0)" class="phone">(773) 472 3667</a></small><br>Industry biggie meets local startup. Next Door&trade; is born.',
    location1 = new google.maps.LatLng(41.932263,-87.652724),
    location1Desc = 'Free Beginner Yoga - 7:15pm',
    location2 = new google.maps.LatLng(41.935455,-87.652681),
    location2Desc = '20% off Oil Change for SF Customers',
    location3 = new google.maps.LatLng(41.93619,-87.648926),
    location3Desc = 'Hackathon..';

if ($(window).width() < 500){
  zoomLvl = 15;
}

function initialize() {
  var mapOptions = {
    zoom: zoomLvl,
    center: myLocation,
  };

  map = new google.maps.Map(document.getElementById('map-canvas'),
      mapOptions);

  var myLocationMarker = new google.maps.Marker({
      position: myLocation,
      map: map,
      title: 'Current Location',
      icon: locationImg
  });

  // Next Door
  var nextDoorMarker = new google.maps.Marker({
      position: nextDoor,
      map: map,
      title: 'Next Door'
  });
  var nextDoorWindow = new google.maps.InfoWindow({
      content: nextDoorDesc
  });
  google.maps.event.addListener(nextDoorMarker, 'click', function() {
    nextDoorWindow.open(map,nextDoorMarker);
  });

  // Location 1
  var location1Marker = new google.maps.Marker({
      position: location1,
      map: map,
      title: 'Free beginner yoga classes 7:15pm',
      icon: bluePointer
  });
  var location1Window = new google.maps.InfoWindow({
      content: location1Desc
  });
  google.maps.event.addListener(location1Marker, 'click', function() {
    location1Window.open(map,location1Marker);
  });

  // Location 2
  var location2Marker = new google.maps.Marker({
      position: location2,
      map: map,
      title: '20% off oil change',
      icon: bluePointer
  });
  var location2Window = new google.maps.InfoWindow({
      content: location2Desc
  });
  google.maps.event.addListener(location2Marker, 'click', function() {
    location2Window.open(map,location2Marker);
  });

  // Location 3
  var location3Marker = new google.maps.Marker({
      position: location3,
      map: map,
      title: 'Hackathon..',
      icon: bluePointer
  });
  var location3Window = new google.maps.InfoWindow({
      content: location3Desc
  });
  google.maps.event.addListener(location3Marker, 'click', function() {
    location3Window.open(map,location3Marker);
  });

}

google.maps.event.addDomListener(window, 'load', initialize);
