$(document).ready(function(){
    $('.radio-one').click(function(){
    	console.log('Yes');
    	// var $this = $('radio-one input')
    	// if ($(this).prop('checked')) {
     //      $('.bar-one').addClass('opacity');
     //    } else {
     //      $('.bar-one').removeClass('opacity');
     //    }
        $('.bar-one').toggleClass('opacity');
    });

    //  $('.radio-one input').click(function () {
    //     var $this = $('.bar-one');
    //     $this.children('input').prop('checked', true);       
    //     $this.siblings('td').removeClass('sel');        
    //     $this.addClass('sel');        
    // });
});